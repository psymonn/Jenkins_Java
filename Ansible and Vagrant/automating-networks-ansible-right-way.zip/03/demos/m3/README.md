# Module 3
Contains some examples of basic infrastructure-as-code, complete with
all of its imperfections and limitations. The following subdirectories
exist:

1. `ios_config_set`: Uses the classic `ios_config` module.
2. `cli_config_set`: Uses the modern (under development)`cli_config` module.
3. `ios_vrf_set`: Uses the very specific `ios_vrf` module.
