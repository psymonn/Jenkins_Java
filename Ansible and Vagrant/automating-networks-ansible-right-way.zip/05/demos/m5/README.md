# Module 5
A fully-functional and idempotent example of shell-based
infrastructure as code. Includes `set_theory.py` script for
simplified experimentation and learning.
