# Module 2
Introductory topics on using Ansible for network automation.

This repository contains a simple VRF configuration getter
which writes text to files for archival.
