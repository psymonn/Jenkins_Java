# Module 6
Introduces the `ansible-network.network-engine` role as an alternative
to custom Python-based parsers. Effectively, this module is a refactor
of module 5.

Note that the `roles/` directory does not exist because nothing inside
it is included in version control. Please install the correct role using
`mkdir roles && ansible-galaxy install ansible-network.network-engine`.
