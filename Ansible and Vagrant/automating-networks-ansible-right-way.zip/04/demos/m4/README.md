# Module 4
Explores writing custom Ansible filters using Python.
