# Module 7
New ways to build infrastructure as code using new APIs on modern routers.
No more using SSH with "screen scraping" to manage devices.

The APIs include:

1. NETCONF: YANG-modeled XML-over-SSH for device management.
2. RESTCONF: YANG-modeled JSON-over-HTTP for device management.
